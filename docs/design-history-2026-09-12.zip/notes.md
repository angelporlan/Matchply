# 🎨 Matchply — Sistema de Diseño Completo

Extracción exhaustiva de todos los tokens de diseño, colores, tipografía, espaciados, animaciones y patrones de componentes del código fuente de Matchply.

> [!NOTE]
> Los archivos fuente principales son: [tailwind.config.ts](file:///Users/angel/devp/NextProf%20AI/tailwind.config.ts), [globals.css](file:///Users/angel/devp/NextProf%20AI/src/app/globals.css), [layout.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/layout.tsx), y [desing_notes.md](file:///Users/angel/devp/NextProf%20AI/desing_notes.md).

---

## 1. Paleta de Colores (Regla 60-30-10)

### Colores de Marca

| Rol | Hex | RGB | Uso |
|---|---|---|---|
| 🖼️ **Canvas Claro (60%)** | `#FAFAFA` | `250, 250, 250` | Fondo base modo claro |
| 🌑 **Canvas Oscuro (60%)** | `#0B0F19` | `11, 15, 25` | Fondo base modo oscuro |
| 🔤 **Medianoche (30%)** | `#1E1B4B` | `30, 27, 75` | Texto principal, navegación, estructura (modo claro) |
| 📖 **Texto Claro (30%)** | `#F3F4F6` | `243, 244, 246` | Texto principal (modo oscuro) |
| 🃏 **Tarjeta Oscura (30%)** | `#1F2937` | `31, 41, 55` | Fondo de tarjetas (modo oscuro) |
| ✅ **Esmeralda (10%)** | `#2ECC71` | `46, 204, 113` | CTAs, éxito, crecimiento |
| ✅ **Esmeralda Hover** | `#27AE60` | `39, 174, 96` | Estado hover de botones verdes |
| 🤖 **Púrpura IA (10%)** | `#8B5CF6` | `139, 92, 246` | **Exclusivo** para elementos de IA |
| 🔵 **Body Forzado** | `#030712` | `3, 7, 18` | Hardcoded en `<body>` del layout |

### Colores del Logo

| Parte | Claro | Oscuro |
|---|---|---|
| Barra izquierda | `#4E46E5` | `#B4A9FB` |
| Barra derecha | `#8F84F8` | `#B4A9FB` |
| Texto "Match" | `#1E1B4B` | `white` |
| Texto "ply" | `#8B5CF6` | `#B4A9FB` |

---

### Variables CSS (`:root` en globals.css) — Valores HSL

> [!IMPORTANT]
> Las variables CSS están configuradas como **tema oscuro por defecto**, pero los componentes reales usan clases Tailwind directas con `dark:` variants en lugar de estas variables.

```css
:root {
  --background: 224 71% 4%;          /* Azul-negro muy oscuro */
  --foreground: 213 31% 91%;         /* Gris claro */
  --muted: 223 47% 11%;              /* Oscuro apagado */
  --muted-foreground: 215.4 16.3% 56.9%;  /* Gris medio */
  --popover: 224 71% 4%;             /* Fondo popover oscuro */
  --popover-foreground: 213 31% 91%; /* Texto popover claro */
  --card: 224 71% 4.5%;              /* Fondo tarjeta oscuro */
  --card-foreground: 213 31% 91%;    /* Texto tarjeta claro */
  --border: 222 47% 11.2%;           /* Borde oscuro */
  --input: 222 47% 11.2%;            /* Fondo input oscuro */
  --primary: 210 40% 98%;            /* Casi blanco */
  --primary-foreground: 222.2 47.4% 11.2%; /* Oscuro */
  --secondary: 222 47% 11.2%;        /* Oscuro */
  --secondary-foreground: 210 40% 98%; /* Claro */
  --accent: 217.2 32.6% 17.5%;       /* Acento oscuro */
  --accent-foreground: 210 40% 98%;   /* Claro */
  --destructive: 0 62.8% 30.6%;      /* Rojo oscuro */
  --destructive-foreground: 210 40% 98%; /* Claro */
  --ring: 216 12.2% 83.9%;           /* Gris claro anillo */
  --radius: 0.75rem;                  /* 12px radio base */
}
```

---

### Mapeo Light ↔ Dark (Uso Real en Componentes)

| Propiedad | Modo Claro | Modo Oscuro |
|---|---|---|
| **Fondo página** | `bg-[#fafafa]` | `dark:bg-[#0b0f19]` |
| **Fondo tarjeta** | `bg-white` | `dark:bg-[#1f2937]` |
| **Texto principal** | `text-[#1e1b4b]` | `dark:text-white` |
| **Texto secundario** | `text-[#1e1b4b]/60` | `dark:text-slate-400` |
| **Texto terciario** | `text-[#1e1b4b]/70` | `dark:text-slate-300` |
| **Borde estándar** | `border-[#1e1b4b]/10` | `dark:border-white/5` |
| **Borde reforzado** | `border-[#1e1b4b]/10` | `dark:border-white/10` |
| **Hover fondo** | `hover:bg-[#fafafa]` | `dark:hover:bg-[#1f2937]/50` |

---

### Colores de Plataformas (Kanban)

| Plataforma | Fondo | Texto | Borde |
|---|---|---|---|
| **LinkedIn** | `bg-blue-500/10` | `text-blue-600` / `dark:text-blue-400` | `border-blue-500/20` |
| **InfoJobs** | `bg-orange-500/10` | `text-orange-600` / `dark:text-orange-400` | `border-orange-500/20` |
| **Indeed** | `bg-sky-500/10` | `text-sky-600` / `dark:text-sky-400` | `border-sky-500/20` |
| **Default** | `bg-[#fafafa]` / `dark:bg-[#0b0f19]` | `text-[#1e1b4b]/50` / `dark:text-slate-400` | `border-[#1e1b4b]/10` |

### Colores de AlertModal

| Tipo | Icono | Fondo Glow | Botón |
|---|---|---|---|
| ✅ success | `text-emerald-400` | `bg-emerald-500/5` | `bg-emerald-600 hover:bg-emerald-500` |
| ⚠️ warning | `text-amber-400` | `bg-amber-500/5` | `bg-amber-600 hover:bg-amber-500` |
| 🔴 danger | `text-rose-400` | `bg-rose-500/5` | `bg-rose-600 hover:bg-rose-500` |
| ℹ️ info | `text-sky-400` | `bg-sky-500/5` | `bg-gradient-to-r from-sky-500 to-indigo-600` |

### Gradientes Usados

| Ubicación | Gradiente |
|---|---|
| Hero text highlight | `bg-gradient-to-r from-[#8b5cf6] to-[#2ecc71]` |
| Upgrade button | `bg-gradient-to-r from-amber-500 to-orange-600` |
| Language toggle | `bg-gradient-to-tr from-[#8b5cf6] to-[#1e1b4b]` |
| Botón IA (borde) | `linear-gradient(to right, #8B5CF6, transparent)` |

---

## 2. Tipografía

### Fuentes Importadas (next/font/google)

```typescript
// layout.tsx
const inter = Inter({ subsets: ['latin'], variable: '--font-sans' });
const outfit = Outfit({ subsets: ['latin'], variable: '--font-display' });
```

### Configuración Tailwind

```javascript
// tailwind.config.ts
fontFamily: {
  sans: ['var(--font-sans)', 'Inter', 'system-ui', 'sans-serif'],
  display: ['var(--font-display)', 'Outfit', 'sans-serif'],
}
```

> [!WARNING]
> El documento `desing_notes.md` especifica `Plus Jakarta Sans` o `Satoshi` para display, pero la implementación real usa **Outfit**.

### Escala Tipográfica

| Elemento | Tamaño | Peso | Tailwind |
|---|---|---|---|
| **H1** (Secciones) | 29px | Bold | `text-3xl font-bold` |
| **H2** (Tarjetas) | 20px | SemiBold | `text-xl font-semibold` |
| **H3** (Etiquetas) | 16px | Medium | `text-base font-medium` |
| **Body / Inputs** | 14px | Regular | `text-sm font-normal` |
| **Hero H1** | Responsive | Black | `font-display font-black text-4xl sm:text-6xl tracking-tight leading-[1.1]` |
| **Badges** | 9-10px | Bold | `text-[9px] uppercase font-bold tracking-wider` |
| **Etiquetas pequeñas** | 11px | Bold | `text-[11px] font-bold font-display` |

### Patrones de Uso

| Contexto | Clases |
|---|---|
| Títulos | `font-display font-bold` o `font-display font-semibold` |
| Texto cuerpo | `font-sans` o `font-light` |
| Labels | `text-xs font-medium font-sans` |
| Botones | `font-display font-semibold` |

---

## 3. Espaciado y Geometría (Grid de 8px)

### Border Radius

```javascript
// tailwind.config.ts
borderRadius: {
  lg: 'var(--radius)',               // 12px
  md: 'calc(var(--radius) - 2px)',   // 10px
  sm: 'calc(var(--radius) - 4px)',   // 8px
}
```

| Elemento | Valor | Clase |
|---|---|---|
| Tarjetas, paneles | 12px | `rounded-[12px]` o `rounded-xl` |
| Botones, inputs | 8px | `rounded-[8px]` o `rounded-lg` |
| Badges interiores | 6px | `rounded-[6px]` |
| Círculos completos | 9999px | `rounded-full` |
| Modales | 16px | `rounded-2xl` |

### Sistema de Espaciado

| Elemento | Valor | Clase |
|---|---|---|
| Padding tarjetas | 24px | `p-6` |
| Padding tarjeta compacta | 12-16px | `p-3` a `p-4` |
| Gap columnas Kanban | 32px | `gap-8` |
| Gap vertical tarjetas | 16px | `mb-4`, `space-y-4` |
| Gap formularios | 16px | `gap-4`, `space-y-4` |
| Gap grid stats | 24px | `gap-6` |
| Margen inferior secciones | 40px | `mb-10` |
| Ancho máximo contenido | 80rem | `max-w-7xl` |
| Padding responsivo | Var. | `px-4 sm:px-6 lg:px-8` |
| Altura header | 64px | `h-16` |
| Ancho sidebar | 256px | `w-64` |

---

## 4. Modo Oscuro

### Implementación

- **Método:** `class`-based (`darkMode: 'class'` en tailwind.config)
- **Toggle:** [ThemeToggle.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/ui/ThemeToggle.tsx) — añade/elimina `.dark` en `<html>` y guarda en `localStorage` key `theme`
- **Hidratación SSR:** Script inline en layout.tsx que lee localStorage y `prefers-color-scheme` antes del hydration de React

```javascript
// layout.tsx inline script
try {
  var savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
} catch (e) {}
```

---

## 5. Glassmorphism y Backdrop

### Clases Globales (globals.css)

```css
.glass-card {
  background: rgba(15, 23, 42, 0.45);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.glass-nav {
  background: rgba(10, 15, 30, 0.7);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.glass-nav-ios {
  background: rgba(2, 6, 23, 0.28);
  backdrop-filter: blur(22px) saturate(180%);
  -webkit-backdrop-filter: blur(22px) saturate(180%);
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  box-shadow: 0 1px 0 rgba(255, 255, 255, 0.03),
              0 12px 40px rgba(2, 6, 23, 0.18);
}
```

### Backdrop en Componentes

| Elemento | Claro | Oscuro |
|---|---|---|
| Headers | `bg-[#fafafa]/80 backdrop-blur-md` | `dark:bg-[#0b0f19]/80` |
| Menú móvil | `bg-[#fafafa]/95 backdrop-blur-lg` | `dark:bg-[#0b0f19]/95` |
| Overlay modal | — | `bg-black/80 backdrop-blur-md` |
| Overlay modal alt | — | `bg-[#1e1b4b]/40 dark:bg-black/60 backdrop-blur-sm` |

---

## 6. Sombras

### CSS Custom

```css
.glow-primary { box-shadow: 0 0 40px -5px rgba(56, 189, 248, 0.15); }
.glow-accent  { box-shadow: 0 0 40px -5px rgba(192, 132, 252, 0.15); }
```

### Patrones Tailwind

| Contexto | Clase |
|---|---|
| Tarjetas estándar | `shadow-sm hover:shadow-md` |
| Modales | `shadow-2xl shadow-black/80` |
| Botones | `shadow-sm` o `shadow-md shadow-[#2ecc71]/10` |
| Tarjeta arrastrando | `shadow-2xl shadow-[#8b5cf6]/10` |
| Login card (light) | `shadow-[0_4px_20px_-4px_rgba(30,27,75,0.05)]` |
| Login card (dark) | `shadow-[0_4px_20px_-4px_rgba(0,0,0,0.3)]` |

---

## 7. Animaciones

### Keyframes CSS (globals.css)

````carousel
```css
/* Flotación — Hero mockup */
@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(0.5deg); }
  50%      { transform: translateY(-10px) rotate(-0.5deg); }
}
.animate-float { animation: float 6s ease-in-out infinite; }
```
<!-- slide -->
```css
/* Pulso sutil */
@keyframes pulse-subtle {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%      { opacity: 0.85; transform: scale(0.98); }
}
.animate-pulse-subtle { animation: pulse-subtle 3s ease-in-out infinite; }
```
<!-- slide -->
```css
/* Shimmer/Shine en hover de botón */
@keyframes shimmer-shine {
  0%   { left: -150%; }
  50%  { left: 100%; }
  100% { left: 100%; }
}
.hover-shimmer-btn { position: relative; overflow: hidden; }
.hover-shimmer-btn::after {
  content: '';
  position: absolute;
  top: 0; left: -150%;
  width: 50%; height: 100%;
  background: linear-gradient(to right,
    rgba(255,255,255,0) 0%,
    rgba(255,255,255,0.4) 50%,
    rgba(255,255,255,0) 100%);
  transform: skewX(-25deg);
}
.hover-shimmer-btn:hover::after {
  animation: shimmer-shine 1s ease-in-out infinite;
}
```
````

### Keyframes Tailwind (tailwind.config.ts)

```javascript
keyframes: {
  'accordion-down': {
    from: { height: '0' },
    to: { height: 'var(--radix-accordion-content-height)' },
  },
  'accordion-up': {
    from: { height: 'var(--radix-accordion-content-height)' },
    to: { height: '0' },
  },
  'pulse-subtle': {
    '0%, 100%': { opacity: '1', transform: 'scale(1)' },
    '50%': { opacity: '0.85', transform: 'scale(1.02)' },
  },
},
animation: {
  'accordion-down': 'accordion-down 0.2s ease-out',
  'accordion-up': 'accordion-up 0.2s ease-out',
  'pulse-subtle': 'pulse-subtle 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
}
```

### Utilidades 3D (globals.css)

```css
.perspective-1000 { perspective: 1000px; }
.preserve-3d      { transform-style: preserve-3d; }
.backface-hidden   { backface-visibility: hidden; -webkit-backface-visibility: hidden; }
.rotate-y-180      { transform: rotateY(180deg); }
.carousel-container { perspective: 1200px; transform-style: preserve-3d; }
```

### Framer Motion (LandingPageClient.tsx)

| Animación | Config |
|---|---|
| Word stagger | `staggerChildren: 0.08`, spring stiffness: 140, damping: 18 |
| Carrusel rotación | `animate(rotation, rotation.get() + 360, { duration: 36, ease: 'linear', repeat: Infinity })` |
| Flechas nav | spring con `stiffness: 80, damping: 18` |
| Cursor parpadeo | `opacity: [1, 0, 1]`, repeat Infinity, duration 0.8 |
| Scale highlight | `scale: [1, 1.03, 1]` |

### Patrones de Transición

| Patrón | Clase |
|---|---|
| Genérico | `transition-all duration-300` |
| Color | `transition-colors` |
| Opacidad | `transition-opacity` |
| Transform | `transition-transform` |
| Card flip | `duration-700` |
| Hover lift | `hover:scale-[1.01] hover:-translate-y-0.5` |
| Active press | `active:scale-95` |

---

## 8. Scrollbar Personalizado

Dos clases: `.editor-scrollbar` y `.scrollbar-custom`

```css
/* Ambas comparten el mismo patrón */
width: 6px; height: 6px;
border-radius: 9999px;

/* Light */
thumb: rgba(30, 27, 75, 0.15);    /* Midnight purple al 15% */
thumb:hover: rgba(30, 27, 75, 0.3);

/* Dark */
thumb: rgba(255, 255, 255, 0.10-0.15);
thumb:hover: rgba(255, 255, 255, 0.2-0.3);

scrollbar-width: thin;
```

---

## 9. Sistema de Iconos

- **Librería:** `lucide-react` (v0.379.0)
- **Grosor de trazo:** Estricto `1.75` → `strokeWidth={1.75}` o `stroke-[1.75]`
- **Tamaños:**

| Tamaño | Clase | Uso |
|---|---|---|
| 12px | `w-3 h-3` | Badges, indicadores |
| 14px | `w-3.5 h-3.5` | Inline con texto |
| 16px | `w-4 h-4` | Botones, inputs |
| 20px | `w-5 h-5` | Navegación |
| 24px | `w-6 h-6` | Headers, acciones principales |

- **Icono de IA:** `Sparkles` con `animate-pulse stroke-[1.75]`

---

## 10. Carousel Responsivo (CSS Variables)

```css
:root                         { --carousel-radius: 350px; }
@media (max-width: 1024px)    { --carousel-radius: 260px; }
@media (max-width: 768px)     { --carousel-radius: 190px; }
@media (max-width: 480px)     { --carousel-radius: 130px; }
```

---

## 11. Patrones de Componentes

### Botones

| Variante | Clases |
|---|---|
| **CTA Verde** | `bg-[#2ecc71] hover:bg-[#27ae60] text-white font-semibold py-3.5 rounded-lg shadow-sm font-display` |
| **Nav Primario** | `bg-[#1e1b4b] dark:bg-white text-white dark:text-[#0b0f19] font-bold px-4 py-2 rounded-[8px] font-display` |
| **IA Púrpura** | `bg-[#8b5cf6] hover:bg-[#8b5cf6]/90 text-white rounded-[8px] font-display` + gradiente borde + icono sparkles |
| **Secundario** | `bg-white dark:bg-[#1f2937] border border-[#1e1b4b]/10 dark:border-white/5 rounded-[8px]` |
| **Danger** | `bg-rose-500 hover:bg-rose-600 text-white rounded-[8px]` |
| **Ghost/Icono** | `p-2 rounded-[8px] bg-white dark:bg-[#1f2937] border border-[#1e1b4b]/10 dark:border-white/10` |

### Tarjetas

| Variante | Clases |
|---|---|
| **Estándar** | `bg-white dark:bg-[#1f2937] border border-[#1e1b4b]/10 dark:border-white/5 rounded-[12px] p-6 shadow-sm` |
| **Arrastrando** | `opacity-95 border-[#8b5cf6] shadow-2xl shadow-[#8b5cf6]/10 scale-[1.02] rotate-[-0.5deg]` |
| **Feature (hover glow)** | `radial-gradient(300px circle at X Y, rgba(139, 92, 246, 0.09), transparent 85%)` |

### Inputs

```
bg-white dark:bg-[#0b0f19]
border border-[#1e1b4b]/10 dark:border-[#f3f4f6]/10
rounded-lg py-3 pl-10 pr-4
text-sm text-[#1e1b4b] dark:text-[#f3f4f6]
placeholder-[#1e1b4b]/30 dark:placeholder-[#f3f4f6]/30
focus:border-[#8b5cf6] focus:ring-1 focus:ring-[#8b5cf6]
transition-all font-sans
```

### Badges

| Variante | Clases |
|---|---|
| **PRO** | `bg-amber-500/10 text-amber-500 border border-amber-500/20 text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-[8px]` |
| **Plataforma** | `text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border` |
| **IA** | `bg-[#8b5cf6]/5 dark:bg-[#8b5cf6]/10 border border-[#8b5cf6]/15 dark:border-[#8b5cf6]/20 rounded-full px-4.5 py-2 text-xs text-[#8b5cf6]` |

### Glows Decorativos de Fondo

```html
<!-- Púrpura superior izquierdo -->
<div class="absolute top-[-10%] left-[-10%] w-[50%] h-[50%]
  rounded-full bg-[#8b5cf6]/4 dark:bg-[#8b5cf6]/6 blur-[120px]
  pointer-events-none" />

<!-- Verde/Púrpura inferior derecho -->
<div class="absolute bottom-[20%] right-[-10%] w-[45%] h-[45%]
  rounded-full bg-[#2ecc71]/4 dark:bg-[#8b5cf6]/8 blur-[130px]
  pointer-events-none" />
```

---

## 12. Dependencias de Diseño

| Paquete | Versión | Propósito |
|---|---|---|
| `tailwindcss` | ^3.4.3 | Framework CSS utility-first |
| `postcss` | ^8.4.38 | Procesador CSS |
| `autoprefixer` | ^10.4.19 | Prefijos vendor |
| `framer-motion` | ^12.40.0 | Animaciones avanzadas (landing) |
| `lucide-react` | ^0.379.0 | Librería de iconos SVG |
| `clsx` | ^2.1.1 | Composición de clases |
| `tailwind-merge` | ^2.3.0 | Merge inteligente de clases TW |
| `@hello-pangea/dnd` | ^18.0.1 | Drag & Drop para Kanban |
| `react-intersection-observer` | ^10.0.3 | Animaciones al hacer scroll |

---

## 13. Partículas del Landing (Canvas)

```javascript
// Colores de partículas del canvas de fondo
purple: rgba(139, 92, 246, 0.35)   // #8B5CF6 al 35%
green:  rgba(46, 204, 113, 0.35)   // #2ECC71 al 35%
```

---

> [!TIP]
> **Resumen visual de la regla 60-30-10:**
> - **60%** → `#FAFAFA` (claro) / `#0B0F19` (oscuro) — Lienzo base
> - **30%** → `#1E1B4B` (claro) / `#F3F4F6` + `#1F2937` (oscuro) — Estructura y texto
> - **10%** → `#2ECC71` (éxito/CTAs) + `#8B5CF6` (exclusivo IA) — Acentos
