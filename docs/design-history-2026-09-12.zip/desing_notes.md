1. Personalidad:



El publico objetivo: La van a usar jovenes que esten en busqueda de empleo.



La emoción clave: El usuario al entrar a la app tiene que sentir la app fluida y creativa a la hora de diseñar su cv.



El tono: La app tiene que ser minimalista, no tiene que abrumar al usuario con tantos botones, tiene que ser algo simple y facil de usar a la hora de diseñar su cv, y con un boton de optimizar con ia que le pasas la info de la oferta de trabajo y este la optimiza.

2. Paleta de Colores: "Tech-Growth & Focus"Para transmitir esa sensación de creatividad, crecimiento profesional y optimización inteligente, nos alejaremos de los azules aburridos de oficina y de los tonos estridentes. Usaremos una combinación limpia de verdes vibrantes y púrpuras tecnológicos.Rol del ColorCódigo HexPropósito Visual60% Fondo/Lienzo#FAFAFA (o #0B0F19 para modo oscuro)Un blanco roto ultra-limpio que reduce la fatiga visual y da sensación de amplitud.30% Estructura/Texto#1E1B4B / #F3F4F6Un azul/púrpura de medianoche para tipografía principal y tarjetas, aportando máxima legibilidad.10% Acento (Crecimiento)#2ECC71Verde Esmeralda. Representa éxito, contratación y avance. Ideal para el tablero Kanban y CTAs principales.10% Inteligencia Artificial#8B5CF6Púrpura Eléctrico. Exclusivo para todo lo relacionado con la IA y la optimización de currículums.3. Tipografía: Estética "Indie-SaaS" ModernaPara conectar con un público joven y mantener el tono minimalista, necesitamos fuentes con excelente rendimiento en pantalla y mucha personalidad geométrica.Tipografía Principal (Títulos y Botones): Plus Jakarta Sans o Satoshi. Tienen unas curvas muy limpias, modernas y un aire ligeramente sofisticado que grita "herramienta de nueva generación".Tipografía de Cuerpo (Contenido y Formularios): Inter. Es el estándar de oro en UI por una razón: su legibilidad a tamaños pequeños (como las etiquetas del tablero Kanban o el texto del CV) es insuperable.4. Elementos Visuales Identitarios (El "Lienzo Inteligente")El minimalismo no es aburrido si las formas y los iconos son perfectos.Radios de curvatura: Curvas suaves de 12px para tarjetas del Kanban y contenedores, y 8px para los botones. Esto le quita agresividad a la interfaz y la hace sentir amigable.El Botón de IA (El Rey de la App): El botón de "Optimizar con IA" no puede ser normal. Debe tener un borde sutil con un degradado que vaya del púrpura (#8B5CF6) a un tono translúcido, y un icono de destello (sparkles).Iconos SVG Animados (Efecto Hover)Usaremos iconos lineales (grosor de 1.75px) con transiciones sutiles en CSS (transition: all 0.3s ease):Icono de CV / Plantillas: Un folio lineal. Al pasar el cursor, unas líneas sutiles simulan escribirse dentro del folio.Icono de Optimización (IA): Dos estrellas/destellos. Al hacer hover, giran levemente (5 grados) y escalan un 10%, dando la sensación de que la IA está "viva" y lista para actuar.Icono de Kanban / Seguimiento: Tres columnas de barritas. Al pasar el cursor, la barrita de la primera columna se desliza suavemente hacia la segunda, emulando el movimiento de una postulación.5. Consistencia y Espaciado: Ritmo de 8pxPara que la app se sienta ligera y no abrume, el secreto es darle aire. Los elementos respirarán usando una escala estricta:Padding interior de tarjetas (CVs y Kanban): 24px para que la información no se vea apelotonada.Espaciado entre columnas del Kanban: 32px de separación, manteniendo las tarjetas compactas internamente (16px de margen vertical entre ellas).Gaps en formularios de datos: 16px entre inputs para que el usuario rellene su información de manera fluida y sin agobiarse.6. Micro-interacciones y Experiencia de UsoAquí es donde la app se vuelve "mágica" y adictiva para el usuario:El Proceso de Optimización: Al hacer clic en "Optimizar con IA", el botón no muestra un spinner de carga aburrido. En su lugar, la tarjeta del CV se cubre con un sutil velo púrpura semi-transparente con un efecto de destello de abajo hacia arriba (shimmer effect), simulando que la IA está escaneando el documento. Al terminar, los textos optimizados aparecen con un suave fade-in.Arrastrar en el Kanban (Drag & Drop): Cuando el usuario arrastra una postulación de "Enviada" a "Entrevista", la tarjeta reduce ligeramente su opacidad, rota 1 o 2 grados simulando gravedad, y la columna de destino se ilumina con un borde verde esmeralda muy suave (#2ECC71 al 10% de opacidad).Cambio de CV activo: Al alternar entre las diferentes copias de tus currículums, el cambio de plantilla no debe dar un salto brusco. Se aplica una transición lateral suave (slide & fade) para que parezca que estás pasando las páginas de un dossier físico.🎨 Visualiza la Interfaz Principal:Imagina entrar a la app: una barra lateral izquierda minimalista con solo 3 opciones (Mis CVs, Kanban, Ajustes). En el centro, tu lienzo. Si estás editando, a la derecha se despliega un panel limpio donde pegas la oferta de empleo; abajo, un único botón grande y redondeado, de color púrpura profundo que dice "Optimizar CV para esta oferta". Un clic, un destello, y tu CV se adapta de inmediato para destacar frente a los reclutadores.

implementation plan desing:

# Plan de Implementación — Nuevo Sistema de Diseño (NextProd AI)

Este documento detalla el plan estratégico y técnico paso a paso para migrar la interfaz visual y la experiencia de usuario (UX) de **NextProf AI** al nuevo sistema de diseño especificado en [design.md](file:///Users/angel/devp/NextProf%20AI/design.md).

---

## 1. Resumen de Directrices del Sistema de Diseño (design.md)

La migración unificará toda la plataforma bajo principios de minimalismo moderno (*Indie-SaaS*), eliminando el ruido visual y optimizando los flujos de interacción con los siguientes tokens de diseño:

### 🎨 Paleta de Colores (Regla 60-30-10)
*   **Modo Claro (Predeterminado):**
    *   **60% Fondo / Lienzo:** `#FAFAFA` (Blanco roto neutro).
    *   **30% Estructura y Texto:** `#1E1B4B` (Medianoche profundo para textos principales, navegación y contenedores secundarios).
    *   **10% Acento Empleo (Crecimiento):** `#2ECC71` (Verde esmeralda para éxitos y CTAs estándar).
    *   **10% Especial (Inteligencia Artificial):** `#8B5CF6` (Púrpura eléctrico - **uso exclusivo** para IA).
*   **Modo Oscuro (Opcional):**
    *   **60% Fondo / Lienzo:** `#0B0F19` (Azul oscuro abisal).
    *   **30% Estructura y Texto:** `#F3F4F6` (Textos) / `#1F2937` (Tarjetas).

### ✍️ Tipografía & Jerarquía
*   **Títulos y Botones Principales:** `Plus Jakarta Sans` o `Satoshi` (Sans-Serif geométrica estilizada).
*   **Cuerpo de Texto y Formularios:** `Inter` (Estándar de legibilidad).
*   **Escala Adaptada:**
    *   `H1` (Secciones): `22pt` (Bold) -> `29px` / `text-3xl font-bold`
    *   `H2` (Tarjetas / Subsecciones): `15pt` (SemiBold) -> `20px` / `text-xl font-semibold`
    *   `H3` (Etiquetas / Títulos menores): `12pt` (Medium) -> `16px` / `text-base font-medium`
    *   `Body / Inputs:` `10.5pt` (Regular) -> `14px` / `text-sm font-normal`

### 📐 Geometría y Consistencia (Múltiplos de 8px)
*   **Contenedores principales:** `border-radius: 12px;` (`rounded-xl` en Tailwind) con sombra suave (`box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05)`).
*   **Botones y Elementos de Entrada:** `border-radius: 8px;` (`rounded-lg` en Tailwind).
*   **Sistema de Espaciados (Obligatorio):**
    *   `Padding interior de tarjetas (CVs y Kanban):` `24px` (`p-6`).
    *   `Separación entre columnas del Kanban:` `32px` (`gap-8`).
    *   `Margen vertical entre tarjetas Kanban:` `16px` (`space-y-4` o `mb-4`).
    *   `Gaps en formularios de datos de usuario:` `16px` (`gap-4`).

### ✨ Micro-interacciones & Estados
*   **Botón IA:** Borde con gradiente sutil `linear-gradient(to right, #8B5CF6, transparent)` e icono SVG lineal de destello (`sparkles`).
*   **Grosor de Iconos (Lucide Icons):** Estricto a `1.75px` (`strokeWidth={1.75}`).
*   **Transiciones Hover (0.3s ease):**
    *   *Icono Folio (CV):* Simular dibujado secuencial de líneas.
    *   *Icono IA (Destellos):* Escala al 110% y rotación de `5deg` a la derecha.
    *   *Icono Kanban (Columnas):* Animación de un nodo deslizándose de col 1 a col 2.
*   **Estados de Carga:**
    *   *Carga IA:* Velo púrpura semi-transparente (`#8B5CF6` al 5% de opacidad, i.e., `bg-[#8B5CF6]/5`) con efecto de barrido de luz vertical (*shimmer*). Revelado por *fade-in*.
    *   *Drag & Drop:* Rotación de la tarjeta arrastrada `1-2 grados`. Columna receptora activa contorno verde esmeralda (`#2ECC71`).

---

## 2. Plan Global de Cimentación (Estilos Core)

Antes de migrar las páginas, es indispensable preparar las bases globales del proyecto para que los estilos se apliquen automáticamente de manera coherente.

### 🌐 [MODIFY] [globals.css](file:///Users/angel/devp/NextProf%20AI/src/app/globals.css)
*   Alinear las variables CSS (`:root`) del tema base (`@layer base`) al **Modo Claro** predeterminado de `design.md`, y configurar el **Modo Oscuro** (`.dark`) con los colores correctos.
*   Definir clases de animación y utilidades reutilizables:
    *   `animate-shimmer` para el efecto de barrido de luz en carga de IA.
    *   `animate-fade-in` para la transición de texto de la IA.
    *   `icon-hover-sparkles`, `icon-hover-folio` e `icon-hover-kanban` para configurar las micro-interacciones de hover requeridas.
    *   Establecer la importación de tipografías (`Plus Jakarta Sans` e `Inter`) de Google Fonts en el encabezado o mediante Next.js `next/font`.

### ⚙️ [MODIFY] [tailwind.config.ts](file:///Users/angel/devp/NextProf%20AI/src/tailwind.config.ts)
*   Modificar la configuración tipográfica:
    *   `font-sans`: Asociar con la tipografía `Inter`.
    *   `font-display`: Asociar con `Plus Jakarta Sans`.
*   Alinear los tokens de color extendidos:
    *   Configurar colores temáticos clave utilizando los códigos exactos del manual (por ejemplo, `#1E1B4B` como `indigo-midnight`, `#2ECC71` como `emerald-growth`, `#8B5CF6` como `purple-electric`, y `#FAFAFA` como `offwhite-canvas`).
*   Modificar los valores predeterminados de `borderRadius`:
    *   `rounded-xl`: `12px` (Tarjetas y paneles).
    *   `rounded-lg`: `8px` (Botones y inputs).

---

## 3. Plan de Migración Página por Página

A continuación se detalla la reestructuración visual agrupada por las **7 áreas principales** de la aplicación, subdivididas en sus componentes e interfaces correspondientes.

---

### 🏠 Componente 1: Página de Inicio / Landing
**Archivo:** [page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/page.tsx)

#### 🗺️ Barra de Navegación Superior
*   **Problema actual:** Utiliza clases oscuras forzadas (`bg-[#030712]`, `.glass-nav-ios` con fondo oscuro).
*   **Propuesta de rediseño:**
    *   Ajustar a fondo semi-transparente en base al tema claro (`bg-[#FAFAFA]/75` con `backdrop-blur-md`).
    *   Cambiar los textos de enlaces a `#1E1B4B` con hovers sutiles en púrpura `#8B5CF6`.
    *   Ajustar el logotipo para usar `font-display` y colores de acento coherentes.
    *   Unificar el botón de login/registro a `rounded-lg` (8px) y tipografía de botones `Plus Jakarta Sans`.

#### 🚀 Sección Hero & Llamada a la Acción (CTA)
*   **Problema actual:** Fondo oscuro duro y degradados de colores genéricos.
*   **Propuesta de rediseño:**
    *   Sustituir el fondo azulado abisal por un lienzo blanco roto `#FAFAFA` limpio con una sutil cuadrícula o luz radial púrpura de IA (`#8B5CF6` al 3%).
    *   El título `H1` debe usar obligatoriamente `Plus Jakarta Sans` en negrita con el tamaño exacto `H1` (29px) en color `#1E1B4B`.
    *   Rediseñar el botón principal "Optimizar Mi CV Ahora" para usar verde esmeralda `#2ECC71` con bordes redondeados de 8px, y el botón secundario con el color estructurado `#1E1B4B`.

#### 📊 Rejilla de Características (Features Grid)
*   **Problema actual:** Tarjetas con diseño oscuro rígido y bordes blancos duros.
*   **Propuesta de rediseño:**
    *   Actualizar las tarjetas al estilo `design.md`: fondo estructurado claro (o gris pizarra suave en oscuro), `border-radius: 12px`, padding interno exacto de `24px` (`p-6`) y sombras difuminadas suaves (`shadow-sm`).
    *   Cambiar los iconos internos para usar estrictamente `strokeWidth={1.75}` de Lucide.

#### 🎴 Carrusel / Catálogo de Plantillas
*   **Problema actual:** Uso de bordes grises oscuros y colores aleatorios sin un tono unificado.
*   **Propuesta de rediseño:**
    *   Rediseñar las tarjetas de las 5 plantillas para reflejar la pulcritud suiza.
    *   Ajustar la tipografía de las cabeceras de tarjeta a `Plus Jakarta Sans` y cuerpo a `Inter`.
    *   Alinear los padding a múltiplos de 8px e integrar micro-interacciones sutiles en hover (escala ligera y sombras realzadas).

#### 💳 Tabla de Planes de Suscripción (Pricing Grid)
*   **Problema actual:** Plan recomendado destaca con azul cielo fuerte (`border-sky-500/30`) y fondos oscuros.
*   **Propuesta de rediseño:**
    *   Reestructurar visualmente ambas tarjetas en tono claro: fondo blanco roto, estructura con bordes suaves de color `#1E1B4B` al 10% de opacidad.
    *   La tarjeta Pro "Recomendado" destacará con un borde acentuado en púrpura eléctrico `#8B5CF6` (por ser el plan que contiene la IA) y detalles en verde `#2ECC71`.
    *   Botón Pro con degradado de IA o color verde de éxito, con `border-radius: 8px`.

#### 👣 Pie de Página (Footer)
*   **Problema actual:** Clases oscuras de texto gris apagado.
*   **Propuesta de rediseño:**
    *   Fondo `#FAFAFA`, borde superior muy fino de color `#1E1B4B` al 5%.
    *   Textos en tipografía `Inter` en tamaño regular de 10.5pt (14px) en color gris neutro oscuro.

---

### 🔐 Componente 2: Páginas de Autenticación
**Archivos:** [(auth)/login/page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/%28auth%29/login/page.tsx) y `register/page.tsx`

#### 🌌 Lienzo del Fondo y Contenedor Principal
*   **Problema actual:** Fondos negros abisales y resplandores de colores neón azul.
*   **Propuesta de rediseño:**
    *   Cambiar a fondo claro `#FAFAFA` con un degradado radial sutil hacia las esquinas inferiores con púrpura eléctrico `#8B5CF6` al 4% de opacidad para simbolizar la IA NextGen.
    *   El contenedor de formulario (`glass-card`) se transformará en una tarjeta premium clara: fondo blanco puro, borde de 1px en `#1E1B4B` con un 5% de opacidad, `rounded-xl` (12px) y sombra suave.

#### 📝 Formulario de Datos (Inputs y Etiquetas)
*   **Problema actual:** Campos oscuros con bordes rígidos y etiquetas apagadas.
*   **Propuesta de rediseño:**
    *   Alinear el espaciado vertical entre campos al gap obligatorio de `16px` (`space-y-4`).
    *   Cambiar los inputs a fondos blancos con bordes suaves `#1E1B4B` (opacidad 10%) que se iluminan al hacer foco con un contorno púrpura `#8B5CF6`.
    *   Bordes redondeados de inputs estrictamente en `8px` (`rounded-lg`).
    *   Etiquetas en tipografía `Inter` en tamaño regular de 10.5pt (14px) de color `#1E1B4B`.

#### 🔘 Botones de Acción (Estándar y Google OAuth)
*   **Problema actual:** Gradiente azul de estilo clásico.
*   **Propuesta de rediseño:**
    *   Botón de iniciar sesión unificado a verde `#2ECC71` con texto en tipografía `Plus Jakarta Sans` semibold y bordes `rounded-lg` (8px).
    *   Botón de Google con estilo minimalista: fondo blanco con un contorno muy fino y texto en `#1E1B4B` (30%).

---

### 💻 Componente 3: Panel de Control (Dashboard)
**Archivos:** [dashboard/page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/dashboard/page.tsx) y [DashboardClient.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/dashboard/DashboardClient.tsx)

#### 🧭 Barra de Navegación del Panel
*   **Problema actual:** Clases oscuras de fondo y bordes oscuros rígidos.
*   **Propuesta de rediseño:**
    *   Fondo semi-transparente claro con efecto de desenfoque (`bg-[#FAFAFA]/80 backdrop-blur-md`).
    *   Borde inferior en `#1E1B4B` al 8% de opacidad.
    *   Enlaces del panel principal (Kanban, Suscripción) estilizados en color `#1E1B4B` con hovers dinámicos en púrpura `#8B5CF6`.

#### 📈 Panel de Estadísticas Rápidas & Alertas
*   **Problema actual:** Diseños oscuros con tarjetas de estadísticas planas en gris oscuro.
*   **Propuesta de rediseño:**
    *   Transformar las tres tarjetas de estadísticas (Postulaciones, Entrevistas, Éxitos): fondo blanco roto, `border-radius: 12px`, padding interior exacto de `24px` (`p-6`).
    *   Color de números principales a `#1E1B4B` con tipografía `Plus Jakarta Sans` en negrita.
    *   Asignar verde esmeralda `#2ECC71` para la tarjeta de ofertas conseguidas, y púrpura `#8B5CF6` para los procesos activos.
    *   El banner de alerta de cuenta gratuita cambiará a fondo púrpura muy suave (`bg-[#8B5CF6]/5`) con borde eléctrico para motivar la actualización Pro.

#### 🗂️ Cuadrícula de CVs (CV Cards Grid)
*   **Problema actual:** Bordes celestes brillantes y colores de acento no estandarizados.
*   **Propuesta de rediseño:**
    *   Cuadrícula alineada con gaps de `24px` (`gap-6`).
    *   Las tarjetas de CV usarán fondo blanco estructurado con bordes suaves de 1px.
    *   La tarjeta marcada como **Principal** destacará mediante un contorno en color `#8B5CF6` y una etiqueta superior en púrpura con el icono de estrella dorada.
    *   El indicador lateral de color se mantendrá pero refinado a la paleta de diseño.
    *   El hover en las tarjetas de CV implementará la animación de micro-interacción en el icono de currículum (Folio) simulando el dibujado de líneas verticales internas.

#### 🆕 Formulario de Creación Rápida de CV
*   **Problema actual:** Campos oscuros con botones en degradados azules clásicos.
*   **Propuesta de rediseño:**
    *   Input de texto en color blanco con bordes `rounded-lg` (8px) y tipografía de texto `Inter`.
    *   Botón "Crear CV" estilizado en verde `#2ECC71` con tipografía `Plus Jakarta Sans` y bordes de 8px.

#### 🔮 Cajón Lateral / Modal de Optimización por IA
*   **Problema actual:** Fondos oscuros de modal y estilos de tarjeta de opciones rígidas.
*   **Propuesta de rediseño:**
    *   Modal adaptado al tema del sistema de diseño (fondo blanco puro con sombra de gran difuminación y velo de fondo semi-transparente `#1E1B4B` al 40%).
    *   Las tres opciones de modo (Fidelidad, Rendimiento, Extremo) se reestructurarán visualmente:
        *   Fidelidad: Detalles en color azul `#38bdf8`.
        *   Rendimiento: Detalles en color amarillo/ocre `#eab308`.
        *   Extremo: Detalles en color naranja/rojo `#ea580c`.
        *   Mantener el hover dinámico y el borde activo de selección, pero adaptado al tema claro.
    *   El botón principal de inicio de optimización de IA adoptará el estilo exclusivo del manual: gradiente lineal púrpura en el borde (`linear-gradient(to right, #8B5CF6, transparent)`) y el icono de destello (`sparkles`).
    *   El cargador IA implementará el velo púrpura semi-transparente del 5% de opacidad (`bg-[#8B5CF6]/5`) y el efecto de barrido de luz vertical (*shimmer*).

---

### 📋 Componente 4: Seguimiento (Tablero Kanban)
**Archivos:** [dashboard/kanban/page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/dashboard/kanban/page.tsx), [KanbanBoard.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/kanban/KanbanBoard.tsx), [KanbanCard.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/kanban/KanbanCard.tsx) y [JobOfferDetailsModal.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/kanban/JobOfferDetailsModal.tsx)

#### 🗺️ Barra de Navegación y Filtros
*   **Problema actual:** Controles oscuros con deslizadores y botones planos.
*   **Propuesta de rediseño:**
    *   La barra de búsqueda y los selectores de filtro de CV adoptarán fondos blancos limpios con contornos suaves de color `#1E1B4B` (10%).
    *   Botón "Nueva Candidatura" en verde `#2ECC71` con bordes de 8px.
    *   Alinear los componentes de filtro con la tipografía de cuerpo `Inter`.

#### 🏛️ Estructura del Tablero y Columnas
*   **Problema actual:** Gaps de columnas compactos y colores de fondo oscuros.
*   **Propuesta de rediseño:**
    *   Separación horizontal obligatoria entre las 5 columnas configurada exactamente a `32px` (`gap-8`).
    *   Fondos de columna en un blanco roto ligeramente diferenciado o gris muy claro para estructura.
    *   Cabeceras de columna con sus colores temáticos suavizados (Interesado, Postulado, Entrevista, Oferta, Rechazado) con iconos Lucide unificados a `strokeWidth={1.75}`.
    *   El hover dinámico en el icono de Kanban simulará el desplazamiento del nodo interactivo de la primera columna a la segunda.

#### 🎴 Tarjeta de Candidatura (KanbanCard)
*   **Problema actual:** Padding variable y falta de animaciones realistas.
*   **Propuesta de rediseño:**
    *   Margen vertical entre tarjetas establecido estrictamente a `16px` (`mb-4`).
    *   Padding interior de las tarjetas a `24px` (`p-6`) para versión cómoda y `16px` para versión compacta.
    *   Fondo de tarjeta blanco con sombra sutil difuminada.
    *   **Drag & Drop Realista:** Añadir soporte en el arrastre para rotar la tarjeta de `1 a 2 grados` simulando inercia física (`rotate-1` o `rotate-2`), y contornear la columna receptora con el color verde esmeralda `#2ECC71` de manera suave.
    *   Iconos de plataforma (LinkedIn, InfoJobs, Indeed) refinados con sus colores corporativos integrados en el sistema.

#### 🔍 Modal de Detalles de Oferta (JobOfferDetailsModal)
*   **Problema actual:** Formulario con estructura oscura y campos planos.
*   **Propuesta de rediseño:**
    *   Modal claro con excelente contraste: títulos en `Plus Jakarta Sans` y textos explicativos en `Inter`.
    *   Campos de formulario editables con la retícula de espaciado vertical de `16px` (`gap-4`).
    *   Botón de guardar cambios en verde `#2ECC71` y botón para "Editar / Ver CV Optimizado" en púrpura eléctrico `#8B5CF6` (por estar asociado con la optimización de IA).

---

### 💳 Componente 5: Suscripción y Facturación
**Archivo:** [dashboard/subscription/page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/dashboard/subscription/page.tsx)

#### 🗺️ Cabecera de Suscripción
*   **Problema actual:** Titulación oscura con degradados en colores planos y fríos.
*   **Propuesta de rediseño:**
    *   Fondo `#FAFAFA` con un degradado radial púrpura extremadamente suave en la parte central.
    *   Ajustar el título principal a `Plus Jakarta Sans` en negrita con el tamaño H1 (29px) en color `#1E1B4B`.

#### 👑 Tarjeta de Socio Pro Activo
*   **Problema actual:** Fondo oscuro abisal y degradados de colores oscuros.
*   **Propuesta de rediseño:**
    *   Si el usuario es PRO, la tarjeta se reestructurará con un diseño *Indie-SaaS* premium: fondo blanco puro, bordes de 1px en púrpura eléctrico `#8B5CF6` con un 15% de opacidad y sombra púrpura muy difuminada.
    *   La insignia de Socio Pro brillará con el color especial IA `#8B5CF6` en tipografía semibold.
    *   El botón de gestión en Stripe adoptará un diseño elegante y limpio en `#1E1B4B` (30%).

#### 🆚 Comparador de Planes (Free vs Pro Cards)
*   **Problema actual:** Colores de acento desequilibrados y sombras muy oscuras.
*   **Propuesta de rediseño:**
    *   Alinear ambas tarjetas con padding interno exacto de `24px` (`p-6`) y bordes de 12px.
    *   La tarjeta Pro destacará por encima de la Free implementando un sutil gradiente púrpura `#8B5CF6` al 3% en su fondo y una corona dorada o de IA.
    *   Los checks de características utilizarán verde `#2ECC71` para denotar crecimiento y aceptación ATS.

---

### 📝 Componente 6: Editor Dividido (Split-Screen)
**Archivos:** [editor/[cvId]/page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/editor/%5BcvId%5D/page.tsx), [EditorClient.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/editor/EditorClient.tsx), [MarkdownEditor.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/editor/MarkdownEditor.tsx) y [PdfViewer.tsx](file:///Users/angel/devp/NextProf%20AI/src/components/editor/PdfViewer.tsx)

#### 🗺️ Cabecera del Editor
*   **Problema actual:** Estructura de fondo oscuro y texto celeste plano.
*   **Propuesta de rediseño:**
    *   Estilo claro: fondo `#FAFAFA`, textos en `#1E1B4B` con la tipografía de títulos `Plus Jakarta Sans`.
    *   Botón "Optimizar con IA" rediseñado con el estilo exclusivo: borde con gradiente lineal sutil en su borde (`linear-gradient(to right, #8B5CF6, transparent)`) y el icono de destello (`sparkles`) con rotación de 5 grados y escala 110% en hover.

#### 🛠️ Barra de Herramientas Flotante (Toolbar)
*   **Problema actual:** Controles e inputs de rango de escala con colores oscuros genéricos.
*   **Propuesta de rediseño:**
    *   Fondo semi-transparente en `#FAFAFA` con desenfoque de fondo.
    *   Selectores de plantilla (Harvard, Modern...) y fuente con bordes `rounded-lg` (8px) y tipografía `Inter`.
    *   Controles deslizantes (margin y escala) refinados con colores de acento `#1E1B4B` y `#2ECC71`.
    *   Paleta de acento manual con selectores circulares con sombras limpias.

#### 🔀 Workspace Dividido y Resizer
*   **Problema actual:** El tirador resizer tiene un degradado oscuro con una línea azul rígida.
*   **Propuesta de rediseño:**
    *   Tirador resizer estilizado en gris claro neutro con hovers sutiles que iluminan la línea central en el púrpura eléctrico `#8B5CF6` de la IA.

#### ✍️ Editor de Texto (Modo Visual & Markdown)
*   **Problema actual:** Colores de sintaxis forzados en el resaltado de Markdown y estilos de barra de formato visual oscuros.
*   **Propuesta de rediseño:**
    *   **Modo Visual (WYSIWYG):** El área editable tendrá tipografía base `Inter` en tamaño regular de 10.5pt (14px). Los encabezados `H1`, `H2` y `H3` respetarán estrictamente la escala tipográfica adaptada y los colores estructurados `#1E1B4B`. La barra de herramientas visual adoptará el estilo claro.
    *   **Modo Markdown:** El visor con resaltado de sintaxis subyacente modificará sus colores: las cabeceras `#` brillarán en púrpura eléctrico `#8B5CF6`, las negritas en blanco/negro intenso y los guiones de lista en verde `#2ECC71`.

#### ⚖️ Comparador de Cambios (Diff Mode)
*   **Problema actual:** Contenedor e indicadores con colores de fondo oscuros apagados.
*   **Propuesta de rediseño:**
    *   La vista unificada y dividida adoptará fondos claros limpios.
    *   Las líneas añadidas (`added`) destacarán en un verde muy suave (`bg-[#2ECC71]/8` con texto verde oscuro) y las eliminadas (`removed`) en un rojo/rosa suave.
    *   Los indicadores de adición (`+`) y sustracción (`-`) utilizarán verde y rojo de alta legibilidad.

#### 📄 Visor PDF (PdfViewer)
*   **Problema actual:** Encabezados oscuros rígidos y mensajes de error o carga con fondos negros.
*   **Propuesta de rediseño:**
    *   Cabecera en blanco roto `#FAFAFA` con controles de zoom en color estructurado `#1E1B4B`.
    *   El velo de carga implementará el Shimmer Effect púrpura semi-transparente.
    *   Mensajes de alerta de timeout de carga rediseñados con bordes redondeados y colores claros.

#### 👣 Barra de Estado Inferior
*   **Problema actual:** Fondo gris oscuro abisal.
*   **Propuesta de rediseño:**
    *   Estilo claro: fondo `#FAFAFA` con borde superior muy fino.
    *   Indicador de estado de guardado dinámico utilizando verde `#2ECC71` con el icono de check en Lucide para denotar éxito al guardar en la nube.

---

### 🛠️ Componente 7: Panel de Administración
**Archivos:** [admin/page.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/admin/page.tsx) y [AdminClient.tsx](file:///Users/angel/devp/NextProf%20AI/src/app/admin/AdminClient.tsx)

#### 🧭 Barra de Navegación y Tabuladores
*   **Problema actual:** Fondo abisal y botones de pestañas oscuros con degradados rígidos.
*   **Propuesta de rediseño:**
    *   Actualizar la cabecera a un blanco roto pulcro.
    *   Los controles de pestañas (Resumen, Usuarios, Modelos IA, Prompts) se reestructurarán en estilo claro: pestaña activa destacada con color estructurado `#1E1B4B` y contorno en púrpura `#8B5CF6`.

#### 📊 Pestaña de Resumen y Estadísticas
*   **Problema actual:** Tarjetas oscuras planas con iconos planos.
*   **Propuesta de rediseño:**
    *   Las tarjetas de estadísticas principales (Total Usuarios, Cvs, Candidaturas, Suscripciones PRO) adoptarán el diseño premium con fondo blanco, bordes redondeados de 12px y padding interno de 24px.
    *   Iconos de acento unificados con stroke de 1.75px.

#### 👥 Pestaña de Gestión de Usuarios y Detalles
*   **Problema actual:** Tablas con filas oscuras rígidas y modal de detalles oscuro.
*   **Propuesta de rediseño:**
    *   Tabla clara: cabecera en gris neutro claro, filas alternas en blanco y blanco roto suave para descanso visual.
    *   Las insignias de rol (Admin) y suscripción (Socio Pro) brillarán con púrpura `#8B5CF6` y verde `#2ECC71` respectivamente sobre fondos pasteles muy claros.
    *   El modal de detalles del usuario se adaptará al estilo de lienzo claro con bordes de 12px.

#### ⚙️ Pestaña de Configuración de Modelos de IA
*   **Problema actual:** Formularios oscuros con selectores oscuros.
*   **Propuesta de rediseño:**
    *   Contenedores de formularios de planes en fondos blanco roto suaves con bordes definidos.
    *   Selectores de proveedores e inputs de modelos en fondo blanco con bordes redondeados de 8px y tipografía `Inter`.

#### 📝 Biblioteca de Prompts y Formulario
*   **Problema actual:** Biblioteca con listas oscuras rígidas y modal de edición oscuro.
*   **Propuesta de rediseño:**
    *   Tarjetas de prompts en fondos claros con el hover dinámico y micro-interacciones.
    *   Formulario de edición de prompt en lienzo claro con campos amplios de texto para el prompt del sistema y usuario alineados con la tipografía mono para código.

---

## 4. Plan de Verificación y Pruebas

Para garantizar que la migración visual no altere la funcionalidad del negocio y que los estilos se apliquen a la perfección, se ejecutará el siguiente plan de pruebas:

### 🤖 Pruebas Automatizadas
1.  **Validación del Build de Producción:**
    ```bash
    npm run build
    ```
    *Garantiza que no existan errores de tipado de TypeScript o importaciones rotas tras el rediseño.*
2.  **Análisis de Reglas de Estilos (Lint):**
    ```bash
    npm run lint
    ```
    *Asegura la coherencia en el código del sistema de diseño.*

### 👁️ Verificación Manual y Visual
*   **Contraste de Accesibilidad:** Validar que el texto en `#1E1B4B` sobre el fondo `#FAFAFA` cumple con el estándar WCAG AA de contraste de texto.
*   **Prueba de Retícula y Responsividad:** Inspeccionar el comportamiento en dispositivos móviles de las tarjetas de CV y el embudo Kanban (asegurando que los gaps de 32px y paddings de 24px se adapten correctamente).
*   **Prueba de Micro-interacciones:** Validar visualmente con la herramienta del inspector los hovers en:
    *   El botón e icono de IA (destello escalado 110% y rotado 5deg).
    *   El comportamiento de rotación de 1-2 grados al arrastrar tarjetas en el Kanban.
    *   El efecto Shimmer en el velo de carga púrpura `#8B5CF6` (5% opacidad) al iniciar una optimización.
*   **Compatibilidad del PDF:** Verificar que el PdfViewer cargue correctamente el iframe en el tema claro y los botones de zoom respondan adecuadamente.
